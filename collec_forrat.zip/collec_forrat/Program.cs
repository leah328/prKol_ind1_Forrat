﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
namespace collec_forrat
{
    class Program
    {
        // 7 задание
        /*  static void Main(string[] args)
          {
              string infix = "3 + 2";
              string[] tokens = infix.Split(' ');

              Stack<string> s = new Stack<string>();
              List<string> outputList = new List<string>();
              int n;
              foreach (string c in tokens)
              {
                  if (int.TryParse(c.ToString(), out n))
                  {
                      outputList.Add(c);
                  }
                  if (c == "(")
                  {
                      s.Push(c);
                  }
                  if (c == ")")
                  {
                      while (s.Count != 0 && s.Peek() != "(")
                      {
                          outputList.Add(s.Pop());
                      }
                      s.Pop();
                  }
                  if (isOperator(c) == true)
                  {
                      while (s.Count != 0 && Priority(s.Peek()) >= Priority(c))
                      {
                          outputList.Add(s.Pop());
                      }
                      s.Push(c);
                  }
              }
              while (s.Count != 0)
              {
                  outputList.Add(s.Pop());
              }
              for (int i = 0; i < outputList.Count; i++)
              {
                  Console.Write("{0}", outputList[i]);

              }

              Console.ReadLine();
          }
          static int Priority(string c)
          {
              if (c == "^")
              {
                  return 3;
              }
              else if (c == "*" || c == "/")
              {
                  return 2;
              }
              else if (c == "+" || c == "-")
              {
                  return 1;
              }
              else
              {
                  return 0;
              }
          }
          static bool isOperator(string c)
          {
              if (c == "+" || c == "-" || c == "*" || c == "/" || c == "^")
              {
                  return true;
              }
              else
              {
                  return false;
              }
          }*/

        //8 задание
        static void Main(string[] args)
        {
            Queue<Person> people = new Queue<Person>();
            string file = "new.txt";
            if (!File.Exists(file))
            {
                if (!string.IsNullOrEmpty(file))
                {
                    Console.WriteLine("файл пустой");
                }
                Console.WriteLine("файл не найден");
            }
            else
            {
                Console.WriteLine("Из файла: --------------");
                string[] s = File.ReadAllLines(file);

                foreach (string ss in s)
                {
                    try
                    {
                        Person p1 = new Person("", "", "", "", 0, 0);
                        string[] peopl = ss.Split(' ');
                        string fam = peopl[0];
                        p1.set_lastname(fam);
                        string name = peopl[1];
                        p1.set_name(name);
                        string ot = peopl[2];
                        p1.set_otfather(ot);
                        string pol = peopl[3];
                        p1.set_pol(pol);
                        int age = Convert.ToInt32(peopl[4]);
                        p1.set_age(age);
                        int zp = Convert.ToInt32(peopl[5]);
                        p1.set_zp(zp);

                        Console.WriteLine($"{p1.get_lastname()} {p1.get_name()} {p1.get_otfather()} {p1.get_pol()} {p1.get_age()} {p1.get_zp()}");

                        people.Enqueue(new Person(fam, name, ot, pol, age, zp));
                    } catch (FormatException) {
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine("строка файла не соотвествует требованиям");
                        Console.ResetColor();
                    }
                }
                Console.WriteLine("------------------------");
                var yung = from p in people
                           where (p.get_age()) < 30
                           select p;
                var notyung = from g in people
                              where (g.get_age()) >= 30
                              select g;
                foreach (var y in yung)
                {
                    Console.WriteLine($"ФИО: {y.get_lastname()} {y.get_name()} {y.get_otfather()} пол - {y.get_pol()} возраст: {y.get_age()} зарплата: {y.get_zp()}");
                }
                foreach (var n in notyung)
                {
                    Console.WriteLine($"ФИО: {n.get_lastname()} {n.get_name()} {n.get_otfather()} пол - {n.get_pol()} возраст: {n.get_age()} зарплата: {n.get_zp()}");
                }
                Console.ReadKey();
            }
        }
    }
}
    

