﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace collec_forrat_form
{
    class Student
    {

        private string fam;
        private string name;
        private string ot;
        private string groug;
        private int mat;
        private int lit;
        private int fiz;

        public Student(string fam, string name, string ot, string groug, int mat, int lit, int fiz)
        {
            this.fam = fam;
            this.name = name;
            this.ot = ot;
            this.groug = groug;
            this.mat = mat;
            this.lit = lit;
            this.fiz = fiz;
        }
        public void set_lastname(string f)
        {
            this.fam = f;
        }
        public string get_lastname()
        {
            return this.fam;
        }
        public void set_name(string f)
        {
            this.name = f;
        }
        public string get_name()
        {
            return this.name;
        }
        public void set_otfather(string f)
        {
            this.ot = f;
        }
        public string get_otfather()
        {
            return this.ot;
        }
        public void set_groug(string f)
        {
            this.groug = f;
        }
        public string get_groug()
        {
            return this.groug;
        }
        public void set_mat(int f)
        {
            this.mat = f;
        }
        public int get_mat()
        {
            return this.mat;
        }

        public void set_lit(int f)
        {
            this.lit = f;
        }
        public int get_lit()
        {
            return this.lit;
        }
        public void set_fiz(int f)
        {
            this.fiz = f;
        }
        public int get_fiz()
        {
            return this.fiz;
        }
    }
}
